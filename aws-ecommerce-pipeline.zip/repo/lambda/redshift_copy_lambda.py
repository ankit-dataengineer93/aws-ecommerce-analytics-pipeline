import boto3

# Explicitly set the region to match where your Redshift Serverless workgroup actually lives
client = boto3.client('redshift-data', region_name='us-east-1')

def lambda_handler(event, context):
    response = client.execute_statement(
        WorkgroupName='ecommerce-workgroup',
        Database='dev',
        Sql="COPY staging_orders FROM 's3://curated--zones/orders/' IAM_ROLE 'arn:aws:iam::170837515790:role/service-role/AmazonRedshift-CommandsAccessRole-20260831T161454' FORMAT AS PARQUET;"
    )
    return {
        'statusId': response['Id'],
        'status': 'STARTED'
    }
