import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.functions import col
from pyspark.sql.types import StructType, StructField, StringType, DoubleType

# ---- Step 1: Get parameters passed in from the Job Details page ----
args = getResolvedOptions(sys.argv, ['JOB_NAME', 'RAW_S3_PATH', 'CURATED_S3_PATH'])

RAW_S3_PATH = args['RAW_S3_PATH']
CURATED_S3_PATH = args['CURATED_S3_PATH']

# ---- Step 2: Boilerplate Glue setup ----
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

# ---- Step 3: Define explicit schema (matches generate_events.py output) ----
orders_schema = StructType([
    StructField("event_id", StringType(), True),
    StructField("customer_id", StringType(), True),
    StructField("product", StringType(), True),
    StructField("price", DoubleType(), True),
    StructField("region", StringType(), True),
    StructField("event_type", StringType(), True),
    StructField("timestamp", StringType(), True)
])

# ---- Step 4: Read the raw CSV from S3 using the explicit schema ----
df = spark.read \
    .option("header", "true") \
    .option("mode", "PERMISSIVE") \
    .schema(orders_schema) \
    .csv(RAW_S3_PATH)

print(f"Rows read from raw zone: {df.count()}")

# ---- Step 5: Clean the data ----
df_clean = df.dropDuplicates()
df_clean = df_clean.dropna(subset=["event_id", "customer_id", "product", "price"])

print(f"Rows after cleaning: {df_clean.count()}")

# ---- Step 6: Write cleaned data as Parquet to curated zone ----
df_clean.write.mode("overwrite").parquet(CURATED_S3_PATH)

print(f"Cleaned data written to: {CURATED_S3_PATH}")

job.commit()
