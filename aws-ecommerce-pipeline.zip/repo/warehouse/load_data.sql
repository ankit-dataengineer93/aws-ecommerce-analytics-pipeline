-- ============================================
-- STEP 1: Create a staging table matching your curated Parquet structure
-- ============================================
CREATE TABLE staging_orders (
    event_id        VARCHAR(100),
    customer_id     VARCHAR(50),
    product         VARCHAR(100),
    price           DOUBLE PRECISION,
    region          VARCHAR(10),
    event_type      VARCHAR(20),
    event_timestamp VARCHAR(50)
);

-- ============================================
-- STEP 2: COPY curated Parquet data from S3 into the staging table
-- ============================================
COPY staging_orders
FROM 's3://curated--zones/orders/'
IAM_ROLE 'arn:aws:iam::170837515790:role/<YOUR_REDSHIFT_IAM_ROLE>'
FORMAT AS PARQUET;

-- ============================================
-- STEP 3: Populate dim_customer from staging (unique customers)
-- ============================================
INSERT INTO dim_customer (customer_id, region)
SELECT DISTINCT customer_id, region
FROM staging_orders
WHERE customer_id NOT IN (SELECT customer_id FROM dim_customer);

-- ============================================
-- STEP 4: Populate dim_product from staging (unique products)
-- ============================================
INSERT INTO dim_product (product_id, product_name)
SELECT DISTINCT product, product
FROM staging_orders
WHERE product NOT IN (SELECT product_id FROM dim_product);

-- ============================================
-- STEP 5: Populate dim_date from staging (unique hour buckets)
-- ============================================
INSERT INTO dim_date (date_id, full_date, year, month, day, hour)
SELECT DISTINCT
    CAST(TO_CHAR(TO_TIMESTAMP(event_timestamp, 'YYYY-MM-DD"T"HH24:MI:SS'), 'YYYYMMDD') AS INT) AS date_id,
    CAST(TO_TIMESTAMP(event_timestamp, 'YYYY-MM-DD"T"HH24:MI:SS') AS DATE) AS full_date,
    EXTRACT(YEAR FROM TO_TIMESTAMP(event_timestamp, 'YYYY-MM-DD"T"HH24:MI:SS')) AS year,
    EXTRACT(MONTH FROM TO_TIMESTAMP(event_timestamp, 'YYYY-MM-DD"T"HH24:MI:SS')) AS month,
    EXTRACT(DAY FROM TO_TIMESTAMP(event_timestamp, 'YYYY-MM-DD"T"HH24:MI:SS')) AS day,
    EXTRACT(HOUR FROM TO_TIMESTAMP(event_timestamp, 'YYYY-MM-DD"T"HH24:MI:SS')) AS hour
FROM staging_orders
WHERE CAST(TO_CHAR(TO_TIMESTAMP(event_timestamp, 'YYYY-MM-DD"T"HH24:MI:SS'), 'YYYYMMDD') AS INT) NOT IN (SELECT date_id FROM dim_date);

-- ============================================
-- STEP 6: Populate fact_orders from staging, joining in the date_id
-- ============================================
INSERT INTO fact_orders (event_id, customer_id, product_id, date_id, event_type, price, event_timestamp)
SELECT
    s.event_id,
    s.customer_id,
    s.product,
    CAST(TO_CHAR(TO_TIMESTAMP(s.event_timestamp, 'YYYY-MM-DD"T"HH24:MI:SS'), 'YYYYMMDD') AS INT),
    s.event_type,
    s.price,
    TO_TIMESTAMP(s.event_timestamp, 'YYYY-MM-DD"T"HH24:MI:SS')
FROM staging_orders s
WHERE s.event_id NOT IN (SELECT event_id FROM fact_orders);

-- ============================================
-- STEP 7: Quick check
-- ============================================
SELECT COUNT(*) AS total_orders FROM fact_orders;
SELECT COUNT(*) AS total_customers FROM dim_customer;
SELECT COUNT(*) AS total_products FROM dim_product;
