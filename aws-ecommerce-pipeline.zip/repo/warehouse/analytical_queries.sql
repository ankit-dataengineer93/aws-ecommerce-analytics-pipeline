-- ============================================
-- QUERY 1: Revenue by day (only counting actual purchases)
-- ============================================
SELECT
    d.full_date,
    ROUND(SUM(f.price), 2) AS total_revenue,
    COUNT(*) AS num_purchases
FROM fact_orders f
JOIN dim_date d ON f.date_id = d.date_id
WHERE f.event_type = 'purchase'
GROUP BY d.full_date
ORDER BY d.full_date;

-- ============================================
-- QUERY 2: Top 5 products by revenue
-- ============================================
SELECT
    p.product_name,
    ROUND(SUM(f.price), 2) AS total_revenue,
    COUNT(*) AS num_purchases
FROM fact_orders f
JOIN dim_product p ON f.product_id = p.product_id
WHERE f.event_type = 'purchase'
GROUP BY p.product_name
ORDER BY total_revenue DESC
LIMIT 5;

-- ============================================
-- QUERY 3: Orders by region (all event types)
-- ============================================
SELECT
    c.region,
    f.event_type,
    COUNT(*) AS event_count
FROM fact_orders f
JOIN dim_customer c ON f.customer_id = c.customer_id
GROUP BY c.region, f.event_type
ORDER BY c.region, event_count DESC;

-- ============================================
-- QUERY 4 (bonus): Conversion funnel — view to cart to purchase
-- ============================================
SELECT
    event_type,
    COUNT(*) AS total_events,
    COUNT(DISTINCT customer_id) AS unique_customers
FROM fact_orders
GROUP BY event_type
ORDER BY
    CASE event_type
        WHEN 'view' THEN 1
        WHEN 'add_to_cart' THEN 2
        WHEN 'purchase' THEN 3
    END;
