-- redshift_schema.sql
-- Star schema for the e-commerce orders pipeline

-- ============================================
-- DIMENSION: dim_customer
-- ============================================
CREATE TABLE dim_customer (
    customer_id     VARCHAR(50)  PRIMARY KEY,
    region          VARCHAR(10)
);

-- ============================================
-- DIMENSION: dim_product
-- ============================================
CREATE TABLE dim_product (
    product_id      VARCHAR(50)  PRIMARY KEY,
    product_name    VARCHAR(100)
);

-- ============================================
-- DIMENSION: dim_date
-- ============================================
CREATE TABLE dim_date (
    date_id         INT          PRIMARY KEY,   -- format: YYYYMMDD, e.g. 20260831
    full_date       DATE,
    year            INT,
    month           INT,
    day             INT,
    hour            INT
);

-- ============================================
-- FACT: fact_orders
-- ============================================
CREATE TABLE fact_orders (
    event_id        VARCHAR(100) PRIMARY KEY,
    customer_id     VARCHAR(50)  REFERENCES dim_customer(customer_id),
    product_id      VARCHAR(50)  REFERENCES dim_product(product_id),
    date_id         INT          REFERENCES dim_date(date_id),
    event_type      VARCHAR(20),
    price           DOUBLE PRECISION,
    event_timestamp TIMESTAMP
);
