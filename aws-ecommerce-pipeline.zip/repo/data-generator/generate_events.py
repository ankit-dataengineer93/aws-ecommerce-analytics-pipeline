import json
import random
import time
import uuid
from datetime import datetime, timezone
import csv

PRODUCTS = ["laptop", "headphones", "keyboard", "monitor", "webcam", "mouse", "desk-lamp"]
REGIONS = ["US", "EU", "IN", "UK", "CA"]

def make_event():
    return {
        "event_id": str(uuid.uuid4()),
        "customer_id": f"cust_{random.randint(1, 500)}",
        "product": random.choice(PRODUCTS),
        "price": round(random.uniform(10, 800), 2),
        "region": random.choice(REGIONS),
        "event_type": random.choice(["view", "add_to_cart", "purchase"]),
        "timestamp": datetime.now(timezone.utc).isoformat()
    }

def run_batch_mode(n=5000, out_file="orders.csv"):
    with open(out_file, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=make_event().keys())
        writer.writeheader()
        for _ in range(n):
            writer.writerow(make_event())
    print(f"Wrote {n} rows to {out_file}")

def run_streaming_mode(stream_name="ecommerce-events", region="us-east-1"):
    import boto3
    client = boto3.client("kinesis", region_name=region)
    print(f"Streaming to {stream_name}... Ctrl+C to stop.")
    while True:
        event = make_event()
        client.put_record(
            StreamName=stream_name,
            Data=json.dumps(event),
            PartitionKey=event["customer_id"]
        )
        print("Sent:", event["event_type"], event["product"])
        time.sleep(random.uniform(0.5, 2))

if __name__ == "__main__":
    import sys
    mode = sys.argv[1] if len(sys.argv) > 1 else "batch"
    if mode == "batch":
        run_batch_mode()
    else:
        run_streaming_mode()
